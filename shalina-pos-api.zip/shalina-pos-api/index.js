const express = require("express");
const cors = require("cors");
const events = require("events");
const eventEmitter = new events.EventEmitter();
const port = process.env.PORT || 3000;
const app = express();
app.use(cors());
app.use(express.json())
require("./src/controller")(app);
require("./bootstrap")(eventEmitter);

console.log(process.env);

function startApp() {
  app.listen(port, () => {
    console.log("Listening on port -- " + port);
  });
}

eventEmitter.once("app started", startApp);
