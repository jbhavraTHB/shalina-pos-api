# Steps for running script

### Pre-requisit for starting application. 

##### Node.js and NPM needs to be installed before starting script. 

- Steps to install Node.js and npm: 
  1. Inside nodejs folder in project directory, unzip `node-v20.11.0-win-x64.zip`.
  2. Provide path of `node-v20.11.0-win-x64` to `PATH` system variable. 
  3. Add path for npm folder to `PATH` variable.

- Verify Installation:
  1. Open command prompt. Press `windows key + R` and type cmd and press enter.
  2. type `node --version` and you will see node version.

##### Configuration setting for application.

 - Go to application folder.
 - Open file with name `pos-rec-prod.json`
 - Under `env` update the following fields with appropriate database settings
   - `DB_HOST` - host address to local database.
   - `DB_USER` - username to local database
   - `DB_PASSWORD` - password to local database
   - `TT_USERNAME` - Thinktribe server username
   - `TT_PASSWORD` - Thinktribe server password
   - `TT_DOMAIN` - Thninktribe server domain
   - `TT_URL` - Thinktribe suggestion url
   - `TT_QTY_URL` - Thinktribe inventory url
- Once done, save the file

#### Starting Application server
- Open command prompt. Press `windows key + R` and type cmd and press enter.
- Navigate to application directory.
- type `call start-script.bat`

After script execution is finished, the application will be started.