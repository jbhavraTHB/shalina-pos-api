module.exports = function(eventEmitter) {
    setTimeout(() => {
        eventEmitter.emit('app started');
    }, 1000)
}