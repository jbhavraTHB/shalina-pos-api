const {
  store_billing_data,
  query_dynamic_procedure,
  query_dynamic_suggestions,
} = require("../helper/db_helper");
const { db_logger } = require("../helper/logger");
const { send_dynamic_recommendations, check_suggestions_quantity } = require("../helper/util");

async function save_billing(req, res) {
  try {
    const { data } = req.body;
    // console.log(data);

    if (!req.body || !req.body.data) {
      res.status(200).send("No billing data");
      return;
    }

    const result = await store_billing_data(data);
    if (result.length > 0) {
      console.log("records saved");
      const transaction_id = data.transaction_id;
      transaction_id && process_dynamic_suggestions(transaction_id);
    }
    res.status(202).send('Success');
    return result;
  } catch (err) {
    res.status(500).send();
    db_logger({
      log_level: "error",
      message: err.message,
      filename: "dynamic_controller",
      method: "save_billing",
      detail: "Error saving billing data",
      payload: Buffer.from(JSON.stringify(req.body), 'base64'),
    });
  }
}

async function process_dynamic_suggestions(transaction_id) {
  try {
    if (transaction_id) {
      const procedure_result = await query_dynamic_procedure(transaction_id);
      if (procedure_result.length) {
        fetch_and_send_suggestions(0, transaction_id);
      }
    }
  } catch (err) {
    db_logger({
      log_level: "error",
      message: err.message,
      filename: "dynamic_controller",
      method: "process_dynamic_suggestions",
      detail: "Error processing dynamic suggestion",
      payload: Buffer.from(`transaction_id:  ${transaction_id}`, 'base64'),
    });

    throw err;
  }
}

async function fetch_and_send_suggestions(counter, transaction_id) {
  try {
    return new Promise(async (resolve) => {
      setTimeout(async () => {
        const suggestion_result = await query_dynamic_suggestions(
          transaction_id
        );
        if (suggestion_result.length < 1 && counter < 3) {
          fetch_and_send_suggestions(counter + 1, transaction_id);
        } else {
          // filter suggestions based on available quantity
          const available_suggestions = await check_suggestions_quantity(suggestion_result);
          // send request to vendor server
          await send_dynamic_recommendations(available_suggestions);
          // console.log("Suggestions: ", suggestion_result);
          resolve();
        }
      }, 5000);
    });
  } catch (err) {
    db_logger({
      log_level: "error",
      message: err.message,
      filename: "dynamic_controller",
      method: "fetch_and_send_suggestions",
      detail: "Error while sending suggestion",
    });
    throw err;
  }
}

module.exports = save_billing;
