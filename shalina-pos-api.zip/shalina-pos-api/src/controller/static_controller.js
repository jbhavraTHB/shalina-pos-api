const {fetch_static_recommendations} = require('../helper/db_helper');
const { db_logger } = require('../helper/logger');

async function get_static_recommendations(req, res) {
    try{
    const { data }  = req.body;
    console.log(data);

    if(!data || !data.customer_id || !data.store_id || !data.terminal_id){
        res.status(400).send('Required data missing');
        return;
    }

    const payload = {
        customer_id: data.customer_id,
        store_id: data.store_id,
        terminal_id: data.terminal_id
    }

    const result = await fetch_static_recommendations(payload);

    return result;
}catch (err) {
    res.status(500).send();
    db_logger({
        log_level: 'error',
        message: err.message,
        filename: 'static_controller',
        method: 'get_static_recommendations',
        detail: 'Error getting static recommendations',
        payload: Buffer.from(JSON.stringify(req.body), 'base64'),
    });
}
}

module.exports = get_static_recommendations;