const save_billing = require('./dynamic_controller');
const get_static_recommendations = require('./static_controller');

function allRoutes() {
  const baseRouter = require("express").Router();
  const staticRouter = require("express").Router();
  const dynamicRouter = require("express").Router();

  baseRouter.get("/", (req, res) => {
    res.send("Welcome");
  });

  staticRouter.post("/get-recommendation", async (req, res) => {
    const result = await get_static_recommendations(req, res);
    res.status(200).send(result);
  });

  dynamicRouter.post("/billing", async (req, res) => {
    const result = await save_billing(req, res);
    res.status(202).send();
  })

  return { baseRouter, staticRouter, dynamicRouter };
}

module.exports = function (app) {
  const { baseRouter, staticRouter, dynamicRouter } = allRoutes();

  app.use('/', baseRouter);
  app.use('/static', staticRouter);
  app.use('/dynamic', dynamicRouter);
};
