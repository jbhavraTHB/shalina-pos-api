const { save_logs } = require("./db_helper");

async function db_logger(data){
    const payload = {
        timestamp: new Date().toISOString(),
        log_level: data.log_level || 'info',
        message: data.message || '',
        filename: data.filename || '',
        method: data.method || '',
        detail: data.detail || '',
        payload: data.payload || ''
    }

    let query = `insert into dbo.Reco_Logs (timestamp, log_level, message, filename, method, detail, payload) values ('${payload.timestamp}', '${payload.log_level}', '${payload.message}', '${payload.filename}', '${payload.method}', '${payload.detail}', '${payload.payload}')`;

    await save_logs(query);
}

async function save_audit_log({message, filename, method, payload}){
    const payload = {
        timestamp: new Date().toISOString(),
        log_level: 'audit',
        message: message || '',
        filename: filename || '',
        method: method || '',
        detail: `Station_id: ${process.env.TT_STATION_ID}`,
        payload: data.payload || ''
    }

    let query = `insert into dbo.Reco_Logs (timestamp, log_level, message, filename, method, detail, payload) values ('${payload.timestamp}', '${payload.log_level}', '${payload.message}', '${payload.filename}', '${payload.method}', '${payload.detail}', '${payload.payload}')`;

    await save_logs(query);
}

module.exports = {
    db_logger,
    save_audit_log
}