const { save_logs } = require("./db_helper");

async function db_logger(data){
    const payload = {
        timestamp: new Date().toISOString(),
        log_level: data.log_level || 'info',
        message: data.message || '',
        filename: data.filename || '',
        method: data.method || '',
        detail: data.detail || '',
        payload: data.payload || ''
    }

    let query = `insert into dbo.Reco_Logs (timestamp, log_level, message, filename, method, detail, payload) values ('${payload.timestamp}', '${payload.log_level}', '${payload.message}', '${payload.filename}', '${payload.method}', '${payload.detail}', '${payload.payload}')`;

    await save_logs(query);
}

module.exports = {
    db_logger
}