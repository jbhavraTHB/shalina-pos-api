// const NtlmClient = require("node-client-ntlm").NtlmClient;
const NtlmClient = require("axios-ntlm").NtlmClient;
const { db_logger } = require("../helper/logger");

let client;
async function init() {
  if (!client) {
    client = NtlmClient({
      username: process.env.TT_USERNAME,
      password: process.env.TT_PASSWORD,
      domain: process.env.TT_DOMAIN,
    });
  }
}

async function send_dynamic_recommendations(result_set = []) {
  console.log("===================================", result_set);
  await init();
  try {
    if (result_set.length === 0) {
      return;
    }
    const dynamic_payload = await create_payload(result_set);

    // send dynamic suggestions

    const response = await client(
      {
        url: process.env.TT_URL,
        method: "POST",
        data: dynamic_payload,
        headers: { "content-type": "application/json" },
      }
    );

    console.log("Think tribe response: ", response);
  } catch (err) {
    console.log(err);
    db_logger({
      log_level: "error",
      message: err.message,
      filename: "util",
      method: "send_dynamic_recommendations",
      detail: "Error while sending dynamic suggestions to TT",
    });
  }
}

async function check_suggestions_quantity(result_set = []) {
  await init();
  try {
    if (result_set.length === 0) {
      return;
    }

    let final_result_set = await Promise.all(
      result_set.map(async (result) => {
        if (result && result.id) {
          let resp = await client({
            url: `${process.env.TT_QTY_URL}(item_id eq '${result.id}' and station_id eq 'SCT-SHP' and batchNo eq '')`,
            method: "get",
          });

          if(resp.data.value[0].quantity > 0){
            return result;
          }
        }
      })
    );

    final_result_set = final_result_set.filter(e => e);
    return final_result_set;
  } catch (err) {
    console.log(err);
    db_logger({
      log_level: "error",
      message: err.message,
      filename: "util",
      method: "check_suggestions_quantity",
      detail: "Error while checking suggestions quantity through TT api",
    });
  }
}

async function create_payload(result_set) {
  let result = {
    store_id: result_set[0].store_id,
    terminal_id: result_set[0].terminal_id,
    transaction_id: result_set[0].transaction_id,
    customer_id: ''+result_set[0].CustomerCode,
    customer_name: result_set[0].customer_name,
    order_status: result_set[0].OrderStatus || "",
    med_recommend: [],
  };

  let recommendation_arr = [];

  await result_set.forEach((element) => {
    let med_reco = {
      sku_code: ''+element.id,
      sku: element.SKU_NAME,
      brand: element.brand || "",
      message: element.Message || "",
      priority_rank: ''+element.PriorityRank,
    };

    recommendation_arr.push(med_reco);
  });
  result.med_recommend = recommendation_arr;
  return result;
}

module.exports = {
  send_dynamic_recommendations,
  check_suggestions_quantity,
};
