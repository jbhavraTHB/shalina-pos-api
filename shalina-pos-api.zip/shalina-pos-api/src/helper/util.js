// const NtlmClient = require("node-client-ntlm").NtlmClient;
const NtlmClient = require("axios-ntlm").NtlmClient;
const { db_logger, save_audit_log } = require("../helper/logger");

let client;
async function init() {
  if (!client) {
    client = NtlmClient({
      username: process.env.TT_USERNAME,
      password: process.env.TT_PASSWORD,
    });
  }
}

async function send_dynamic_recommendations(result_set) {
  console.log("===================================", result_set.length);
  await init();
  try {
    if (result_set.length === 0) {
      console.log('no result_set in send_dynamic_recommendations');
      return;
    }
    const dynamic_payload = await create_payload(result_set);

    // send dynamic suggestions

    const response = await client(
      {
        url: process.env.TT_URL,
        method: "POST",
        data: dynamic_payload,
        headers: { "content-type": "application/json" },
      }
    );

    // console.log("Think tribe response: ", response);
    save_audit_log({
      message: `response from TT: ${response?.data}`,
      filename: "util.js",
      method: "send_dynamic_recommendations",
      payload: ''
    });
  } catch (err) {
    console.log(err);
    db_logger({
      log_level: "error",
      message: err.message,
      filename: "util",
      method: "send_dynamic_recommendations",
      detail: "Error while sending dynamic suggestions to TT",
    });
  }
}

async function check_suggestions_quantity(result_set) {
  console.log("check_suggestions_quantity: ", result_set.length);
  await init();
  try {
    if (result_set.length === 0) {
      console.log('no result_set in check_suggestions_quantity');
      return;
    }

    let final_result_set = await Promise.all(
      result_set.map(async (result) => {
        if (result && result.item_id) {
	        console.log('checking quantity for: ' + result.item_id);
          let resp = await client({
            url: `${process.env.TT_QTY_URL}(item_id eq '${result.item_id}' and station_id eq '${process.env.TT_STATION_ID}' and batchNo eq '')`,
            method: "get",
          });

          if(resp.data.value[0].quantity > 0){
            return result;
          }else{
            console.log('check_suggestions_quantity: No quantity found for' + result.item_id);
          }
        }
      })
    );
    final_result_set = final_result_set.filter(e => e);

    save_audit_log({
      message: `dynamic suggestion after quantity check: ${final_result_set.length}`,
      filename: "util.js",
      method: "check_suggestions_quantity",
      payload: ''
    });

    return final_result_set;
  } catch (err) {
    console.log(err);
    db_logger({
      log_level: "error",
      message: err.message,
      filename: "util",
      method: "check_suggestions_quantity",
      detail: "Error while checking suggestions quantity through TT api",
    });
  }
}

async function create_payload(result_set) {
  let result = {
    store_id: result_set[0].store_id,
    terminal_id: result_set[0].terminal_id,
    transaction_id: result_set[0].transaction_id,
    customer_id: ''+result_set[0].customercode,
    customer_name: result_set[0].customer_name,
    order_status: result_set[0].OrderStatus || "",
    med_recommend: [],
  };

  let recommendation_arr = [];

  await result_set.forEach((element) => {
    let med_reco = {
      sku_code: ''+element.item_id,
      sku: element.sku_name,
      brand: element.brand || "",
      message: element.message || "",
      priority_rank: ''+element.priorityrank,
    };

    recommendation_arr.push(med_reco);
  });
  result.med_recommend = recommendation_arr;
  return result;
}

module.exports = {
  send_dynamic_recommendations,
  check_suggestions_quantity,
};
