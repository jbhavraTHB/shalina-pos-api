const sql = require("mssql");
const { save_audit_log } = require("./logger");

let connection;

const createConnection = async () => {
  try {
    if (!connection) {
      connection = await sql.connect({
        server: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_DATABASE,
        pool: {
          max: 10,
          min: 0,
          idleTimeoutMillis: 30000
        },
        options: {
          encrypt: true,
          trustServerCertificate: true
        }
      });
      // connection.connect();
    }
    return connection;
  } catch (e) {
    console.error("Error connecting connection", e);
  }
};

const fetch_static_recommendations = async (data) => {
  try {
    if (!data) return null;
    await createConnection();
    // console.log(connection);
    const query = `SELECT * FROM dbo.POS_Static_Record WHERE customerid = '${data.customer_id}';`;
    const result = await connection.query(query);

    console.log(result.rowsAffected, "result-count");
    save_audit_log({
      message: `total static records fetched: ${result.rowsAffected}`,
      filename: "db_helper.js",
      method: "fetch_static_recommendations",
      payload: ''
    });
    if (result && result.recordset) {
      return result.recordset;
    }
    return [];
  } catch (e) {
    throw e;
  }
};

const store_billing_data = async (data) => {
  try {
    await createConnection();

    const query = await generate_billing_query(data);
    console.log("query", query);
    const result = await connection.query(query);
    console.log(result.rowsAffected, "result-count");
    save_audit_log({
      message: `nude_billing records saved: ${result.rowsAffected}`,
      filename: "db_helper.js",
      method: "store_billing_data",
      payload: ''
    });
    if (result && result.rowsAffected) {
      return result.rowsAffected;
    }
    return [];
  } catch (e) {
    throw e;
  }
};

const query_dynamic_procedure = async (transaction_id) => {
  try {
    await createConnection();
    console.log(transaction_id);
    const result = await connection.query(
      `EXEC dbo.Dynamic_reco @TransactionID = '${transaction_id}'`
    );
    console.log("procedure output", result);
    save_audit_log({
      message: `stored procedure output: ${result}`,
      filename: "db_helper.js",
      method: "query_dynamic_procedure",
      payload: ''
    });
    if (result && result.rowsAffected) {
      return result.rowsAffected;
    }
    return [];
  } catch (e) {
    throw e;
  }
};

const query_dynamic_suggestions = async (transaction_id) => {
  try {
    await createConnection();
    console.log(transaction_id);
    const result = await connection.query(
      `SELECT * FROM dbo.POS_Nudge_suggestion WHERE transaction_id = '${transaction_id}'`
    );
    console.log(result.rowsAffected, "result-count");
    save_audit_log({
      message: `dynamic suggestion records: ${result.rowsAffected}`,
      filename: "db_helper.js",
      method: "query_dynamic_suggestions",
      payload: ''
    });
    if (result && result.recordset) {
      return result.recordset;
    }
    return [];
  } catch (e) {
    throw e;
  }
};

const save_logs = async (query) => {
  try {
    await createConnection();
    await connection.query(query);
  } catch (err) {
    console.error(err);
  }
};

const generate_billing_query = async (data) => {
  let rows = [];

  data.medicine.forEach((entry) => {
    let row_entry = {
      customer_id: data.customer_id,
      customer_name: data.customer_name,
      transaction_id: data.transaction_id,
      store_id: data.store_id,
      terminal_id: data.terminal_id,
      sku: entry.sku,
      sku_code: entry.sku_code,
      qty: entry.qty,
      loyalty_points: entry.loyalty_points,
      net_amount: entry.net_amount,
      created_at: new Date().toISOString(),
    };

    rows.push(row_entry);
  });

  let query =
    "insert into dbo.POS_Nudge_billing (customer_id, customer_name, transaction_id, store_id, terminal_id, medicine_sku, medicine_item_code, medicine_qty, medicine_loyalty_points, medicine_net_amount, created_at) values";

  let values_list = [];

  rows.forEach((row) => {
    values_list.push(
      `('${row.customer_id}', '${row.customer_name}', '${row.transaction_id}', '${row.store_id}', '${row.terminal_id}', '${row.sku}', '${row.sku_code}', '${row.qty}', ${row.loyalty_points}, ${row.net_amount}, '${row.created_at}')`
    );
  });
  query = `${query}${values_list.join(",")}`;
  return query;
};

module.exports = {
  fetch_static_recommendations,
  store_billing_data,
  query_dynamic_procedure,
  query_dynamic_suggestions,
  save_logs,
};
